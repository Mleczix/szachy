public class mm {

    public static void main(String[] args){
        Window okno = new Window();
        okno.pack();
        okno.refresh();

    }

}
